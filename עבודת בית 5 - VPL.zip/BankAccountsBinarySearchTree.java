
import java.util.Comparator;
import java.util.Iterator;

public class BankAccountsBinarySearchTree extends BinarySearchTree<BankAccount>{

	public BankAccountsBinarySearchTree(Comparator<BankAccount> myComparator) {
		super(myComparator);
	}
	
	public void balance(){
	    throw new UnsupportedOperationException("Remove this line");
	}
	    
	private void buildBalancedTree(List<BankAccount> list, int low, int high) {
	    throw new UnsupportedOperationException("Remove this line");
	}
}
