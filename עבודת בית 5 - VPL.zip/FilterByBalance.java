
public class FilterByBalance implements Filter<BankAccount>{
	public FilterByBalance(int balanceThreshold) {
	    throw new UnsupportedOperationException("Remove this line");
	}
	
	@Override
	public boolean accept(BankAccount element) {
	    throw new UnsupportedOperationException("Remove this line");
	}
}
