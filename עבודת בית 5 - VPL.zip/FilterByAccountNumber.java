
public class FilterByAccountNumber implements Filter<BankAccount> {
    
    public FilterByAccountNumber(int minAccountNum, int maxAccountNum) {
        throw new UnsupportedOperationException("Remove this line");
    }

    public boolean accept(BankAccount element) {
        throw new UnsupportedOperationException("Remove this line");
    }
}
